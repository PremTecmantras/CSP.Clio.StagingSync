<#
  Creates the three Windows Task Scheduler tasks for CSP.Clio.StagingSync.
  Run once in an ELEVATED PowerShell on the server:

    .\Setup_Scheduled_Tasks.ps1 -ExePath "D:\Clio\CSP.Clio.StagingSync.exe"

  Optional: -MorningTime "06:00" -NightTime "21:00" -RunAs "DOMAIN\svc_clio"
  Without -RunAs the tasks run as SYSTEM; SYSTEM needs its own SQL login, so a service account with SQL access is better.
  With -RunAs you are asked for that account's password once.

  Tasks:
    CSP Clio Incremental   every 5 minutes   --incremental
    CSP Clio Full Morning  daily MorningTime --full-check --confirm-publish
    CSP Clio Full Night    daily NightTime   --full-check --confirm-publish
  (every full check also applies the delete reconciliation; add --skip-deletes to a task to leave it out)
  Rules for all: never start a second copy, no time limit, run even when nobody is logged on, run as soon as possible after a missed start.
#>
param(
    [Parameter(Mandatory = $true)][string]$ExePath,
    [string]$MorningTime = "06:00",
    [string]$NightTime = "21:00",
    [string]$RunAs
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path $ExePath)) { throw "EXE not found: $ExePath" }
$workDir = Split-Path -Parent (Resolve-Path $ExePath)

$settings = New-ScheduledTaskSettingsSet `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -StartWhenAvailable `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

if ($RunAs) {
    $cred = Get-Credential -UserName $RunAs -Message "Password of the account that runs the Clio tasks"
    $principal = New-ScheduledTaskPrincipal -UserId $RunAs -LogonType Password -RunLevel Highest
} else {
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
}

function Register($name, $arguments, $trigger) {
    $action = New-ScheduledTaskAction -Execute $ExePath -Argument $arguments -WorkingDirectory $workDir
    $task = New-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -Principal $principal
    if ($RunAs) {
        Register-ScheduledTask -TaskName $name -InputObject $task -User $RunAs -Password $cred.GetNetworkCredential().Password -Force | Out-Null
    } else {
        Register-ScheduledTask -TaskName $name -InputObject $task -Force | Out-Null
    }
    Write-Host "Created: $name  ($arguments)"
}

# Every 5 minutes, all day, starting one minute from now.
$every5 = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
Register "CSP Clio Incremental" "--incremental" $every5

Register "CSP Clio Full Morning" "--full-check --confirm-publish" (New-ScheduledTaskTrigger -Daily -At $MorningTime)
Register "CSP Clio Full Night"   "--full-check --confirm-publish" (New-ScheduledTaskTrigger -Daily -At $NightTime)

Write-Host ""
Write-Host "Done. Check them in Task Scheduler (taskschd.msc) -> Task Scheduler Library."
Write-Host "To test one now:  Start-ScheduledTask -TaskName 'CSP Clio Full Morning'"
