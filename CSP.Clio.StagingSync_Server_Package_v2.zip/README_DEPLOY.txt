﻿CSP.Clio.StagingSync - server deployment (existing staging, no incremental yet)

1. Copy the Build folder to a fixed path on the server, e.g. D:\Clio
2. Edit Build\CSP.Clio.StagingSync.exe.config:
   - connection strings EKPBIEntities (initial catalog Clio_Staging) and ProductionSql (EKPBI_New_Dev): set the server's SQL instance
   - IncrementalInitialLookbackHours: must cover the days since the last extraction in the server's Clio_Staging (default 72)
   - PublishAfterValidation: false
3. Set Clio_Staging to SIMPLE recovery, files on a large drive.
4. Run the scripts in SSMS, in the order of the file names (1..4).
   Script 3 (11_Import...): first with @DryRun = 1, read the result, then @DryRun = 0.
5. By hand, from the Build folder:
   CSP.Clio.StagingSync.exe --incremental
   CSP.Clio.StagingSync.exe --full-check
   CSP.Clio.StagingSync.exe --full-check --confirm-publish
   then check BillingCollDailyCheck.sql on Dev and Prod (variance 0).
6. Only then run Setup_Scheduled_Tasks.ps1 (elevated PowerShell). It creates two tasks: incremental every 5 minutes and
   a publish (--full-check --confirm-publish, with deletes) every 90 minutes. FullCheckLockWaitMinutes (default 10) lets the
   publish wait for a running incremental sync instead of failing.
   NOTE: Pipeline_Workflow.docx still shows the older schedule; Pipeline_Workflow.md is current.
Pipeline_Workflow.docx describes the whole workflow.

